#!/usr/bin/env bash
set -euo pipefail
log() { echo -e "\033[1;32m[XOs]\033[0m $1"; }
log "Installing fnm + Node.js..."
command -v fnm &>/dev/null || curl -fsSL https://fnm.vercel.app/install | bash -s -- --skip-shell
FNM_PATH="$HOME/.local/share/fnm"
SHELL_CONFIG=""
case "$SHELL" in */zsh) SHELL_CONFIG="$HOME/.zshrc" ;; */bash) SHELL_CONFIG="$HOME/.bashrc" ;; */fish) SHELL_CONFIG="$HOME/.config/fish/config.fish" ;; esac
if [ -n "$SHELL_CONFIG" ] && [ -f "$SHELL_CONFIG" ] && ! grep -q "fnm env" "$SHELL_CONFIG"; then
  echo -e "\n# fnm\nexport PATH=\"$FNM_PATH:\$PATH\"\neval \"\$(fnm env --use-on-cd)\"" >> "$SHELL_CONFIG"
fi
export PATH="$FNM_PATH:$PATH"
eval "$(fnm env --use-on-cd)"
fnm install --lts && fnm use --lts
npm install -g npm@latest yarn pnpm typescript ts-node
log "Node $(node -v) — npm $(npm -v)"
