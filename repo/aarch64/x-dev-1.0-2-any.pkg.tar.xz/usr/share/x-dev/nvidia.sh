#!/usr/bin/env bash
set -euo pipefail
log() { echo -e "\033[1;32m[XOs]\033[0m $1"; }
warn() { echo -e "\033[1;33m[!]\033[0m $1"; }
run() { if command -v x &>/dev/null; then x "$@"; elif [ "$EUID" -ne 0 ]; then sudo "$@"; else "$@"; fi; }
log "Installing NVIDIA drivers..."
MULTILIB=false; grep -q "^\[multilib\]" /etc/pacman.conf && MULTILIB=true
pacman -Q vulkan-nouveau xf86-video-nouveau &>/dev/null && run pacman -Rns --noconfirm vulkan-nouveau xf86-video-nouveau || true
PKGS="nvidia nvidia-utils nvidia-settings opencl-nvidia egl-wayland"
$MULTILIB && PKGS="$PKGS lib32-nvidia-utils lib32-opencl-nvidia"
run pacman -S --noconfirm --needed $PKGS
MKINIT=/etc/mkinitcpio.conf
if [ -f "$MKINIT" ] && ! grep -q nvidia_drm "$MKINIT"; then
  run cp "$MKINIT" "${MKINIT}.bak"
  run sed -i 's/^MODULES=(\(.*\))/MODULES=(nvidia nvidia_modeset nvidia_uvm nvidia_drm \1)/' "$MKINIT"
  run mkinitcpio -P
fi
if command -v bootctl &>/dev/null && bootctl is-installed &>/dev/null; then
  for f in /boot/loader/entries/*.conf; do
    [ -f "$f" ] || continue
    grep -q "nvidia-drm.modeset=1" "$f" || run sed -i '/^options/ s/$/ nvidia-drm.modeset=1/' "$f"
    grep -q "nvidia-drm.fbdev=1" "$f" || run sed -i '/^options/ s/$/ nvidia-drm.fbdev=1/' "$f"
  done
elif [ -f /boot/grub/grub.cfg ]; then
  GRUB=/etc/default/grub
  CUR=$(grep "^GRUB_CMDLINE_LINUX_DEFAULT=" "$GRUB" | cut -d'"' -f2)
  NEW="$CUR"
  [[ "$CUR" != *"nvidia-drm.modeset=1"* ]] && NEW="$NEW nvidia-drm.modeset=1"
  [[ "$CUR" != *"nvidia-drm.fbdev=1"* ]] && NEW="$NEW nvidia-drm.fbdev=1"
  [ "$CUR" != "$NEW" ] && { run sed -i "s/^GRUB_CMDLINE_LINUX_DEFAULT=\".*\"/GRUB_CMDLINE_LINUX_DEFAULT=\"$NEW\"/" "$GRUB"; run grub-mkconfig -o /boot/grub/grub.cfg; }
fi
run bash -c 'echo "options nvidia_drm modeset=1 fbdev=1" > /etc/modprobe.d/nvidia.conf'
run systemctl enable --now nvidia-suspend.service nvidia-hibernate.service nvidia-resume.service nvidia-powerd.service || true
log "Done! Reboot required."
